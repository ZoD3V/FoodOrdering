//
//  FoodOrderingApp.swift
//  FoodOrdering
//
//  Created by zero on 01/03/21.
//

import SwiftUI
import Firebase
import FirebaseCore

@main
struct FoodOrderingApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

class AppDelegate:NSObject,UIApplicationDelegate{
    func application(_ application:UIApplication,didFinishLaunchingWithOptions lauchOptions:[UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        FirebaseApp.configure()
        return true
    }
}
